import React from 'react'

export default function Event04() {
  return (
    <div>Event04</div>
  )
}
