import React from 'react'

export default function Practice() {
	/*
	! button 요소를 클릭하는 경우
		: body의 배경색이 토글(변경)되도록 설정
		: 토글의 값 - black, white

		? 요구 사항
		1. button 요소 클릭 시 이벤트 핸들러 실행(handleClick)

		2. handleClick 이벤트는 컴포넌트 내에서 정의 
			>> body의 색상 변경:
			let bodyStyle = document.body.style;
			위의 변수에서 bodyStyle.backgroundColor 속성에 값을 전달하면 
			값이 지정

			>> 토글의 기능을 위해 if, else 구문 사용
	*/
	
	
	function handleClick() {
		let bodyStyle = document.body.style;
		if (bodyStyle.backgroundColor === 'black') 
			{
			bodyStyle.backgroundColor = 'white';
		} else 
		{
			bodyStyle.backgroundColor = 'black';
		}
	}
	return (
		<div>
			<button onClick={handleClick}>
				배경색을 토글합니다.
			</button>
		</div>
	)
}
