import React, { useCallback, useState } from 'react'

//! 장바구니 로직 구현

//& 기능 정리
// - 상품 추가, 상품 수정, 상품 제거

//& 상품 구현
// - 상품 고유 번호 (id), 상품 이름(name), 상품 가격(price), 상품 개수 (quantity) 

//! 상품 타입 명시
type CartItemType = {
	id: number;
	name: string;
	price: number;
	quantity: number;
}

//! 장바구니 로직을 구현하는 커스텀 훅
const useCart = () => {
	const [cartItems, setCartItems] = useState<CartItemType[]>([]);

	const [loading, setloading] = useState(false);
	const [error, setError] = useState<string | null>(null);

	const addItem = useCallback((newItem: CartItemType)=> {
		
		setCartItems(prevItems => {
			const existingItemIndex = prevItems.findIndex(item => item.id === newItem.id);

			if (existingItemIndex !== -1) {
					// 장바구니에 이미 존재하는 경우: 해당 아이템의 수량을 증가
					const updatedCartItems = [...prevItems];
					updatedCartItems[existingItemIndex].quantity += newItem.quantity;
					return updatedCartItems;
			} else {
					// 장바구니에 존재하지 않는 경우: 새로운 아이템 추가
					return [...prevItems, newItem];
			}
	});

	}, [])

	const updateItemQuantity = useCallback((id: number, newQuantity: number) => {

		setCartItems(prevItems => {
			return prevItems.map(item => {
					if (item.id === id) {
							return { ...item, quantity: newQuantity };
					}
					return item;
			});
	});

	}, [])

	const removeItem = useCallback((id: number)=> {
		setCartItems(prevItems => prevItems.filter(item => item.id !== id));
		
	}, [])

	return {cartItems, addItem, updateItemQuantity, removeItem}
}
export default function Cart() {
	

	// 사용자 정의 장바구니 로직 가져오기 - 구조 분해 할당
	// 수정을 위한 input 상태 관리 (name, price)

	const { cartItems, addItem, updateItemQuantity, removeItem } = useCart();
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');

	const handleAddItem = (e: React.FormEvent) => {
		e.preventDefault();
        if (!name || !price) return;
        const newItem: CartItemType = {
            id: Date.now(),
            name,
            price: Number(price),
            quantity: 1 // 임의의 초기 수량
        };
        addItem(newItem);
        setName('');
        setPrice('');
	}
	
	return (
		<div>
			<form onSubmit={handleAddItem}>
			{/* 상품 이름과 가격을 입력 받아서 제품 추가 */}
			<input
        type="text"
        placeholder="상품 이름"
        value={name}
        onChange={e => setName(e.target.value)}
      />

			<input
        type="number"
        placeholder="가격"
        value={price}
        onChange={e => setPrice(e.target.value)}
        />
      <button type="submit">추가</button>
			</form>

			{/* 장바구니 데이터 출력 */}
			<ul>
				{cartItems.map(item => (
					<li key = {item.id}>
					{item.name} - {item.price}원 - {item.quantity}개
					<button onClick={() => updateItemQuantity(item.id, item.quantity + 1)}>수량 증가</button>
          <button onClick={() => updateItemQuantity(item.id, Math.max(1, item.quantity - 1))}>수량 감소</button>
          <button onClick={() => removeItem(item.id)}>제거</button>
				</li>
				))}
				
			</ul>
		</div>
	)
}
