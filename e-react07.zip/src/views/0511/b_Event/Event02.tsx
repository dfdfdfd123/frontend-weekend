import React from 'react'

export default function Event02() {
  return (
    <div>Event02</div>
  )
}
