import React from 'react'

export default function Practice01() {
  return (
    <div>Practice01</div>
  )
}
