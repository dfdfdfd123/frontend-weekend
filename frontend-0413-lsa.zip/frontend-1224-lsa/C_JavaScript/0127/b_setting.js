//! 자바스크립트 개발 환경 설정

// 코드 작성 및 확인
// VSCode 설치, 구글 크롬
// - 개발자 도구 (Console창): f12 / ctrl + shift + i

// 콘솔 창 출력
// : 간단한 코드와 결괏값을 출력, 에러 확인
console.log('Hello JavaScript');