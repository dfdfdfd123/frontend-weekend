// module 디렉터리 내 파일 생성

//? b_module.ts에서 정의된 add, subtract 함수를 사용 
// : 일반 export(내보내기)된 기능 사용 
// - import 뒤의 중괄호 내에 내보내기된 기능의 이름을 동일하게 사용 
import { add, subtract } from '../b_module';

console.log(add(5, 3)); // 8 
console.log(subtract(5, 3)); // 2

//? b_module.ts에서 정의된 Calculator 클래스를 사용 
// - import 시 중괄호를 제외하는 경우는 default 기능임을 자동으로 인식
// - default 기능은 이름을 사용하는 파일에서 임의 지정이 가능
import Calc from '../b_module'
const calculator = new Calc();
console.log(calculator.add(5,6)); // 11

//! 네임스페이스 
// : 논리적으로 그룹화하고, 이름 충돌을 방지하는 방법 

// 장점
// : 코드를 그룹화(관련된 기능들을 묶는 방법)
// : 충돌 방지(전역 스코프에서의 이름 충돌을 예방)
// - 스코프를 하나 만들어서 이름을 붙이는 것과 동일

namespace MyStringAdd {
	export function add(x: string, y: string): string {
		return x + y;
	}
}

// 네임스페이스 : 중괄호에 이름 붙이기와 동일
// - 사용 방법
// 네임스페이스명.기능명

console.log(MyStringAdd.add('이', '승아'));

//! 모듈 vs 네임스페이스
// 모듈 
// : 파일 단위로 코드를 분리
// : ES6 모듈 시스템을 사용

// 네임 스페이스
// : 주로 전역 변수의 오염을 방지하기 위해 사용
// : , 하나의 파일 내에서 사용 

