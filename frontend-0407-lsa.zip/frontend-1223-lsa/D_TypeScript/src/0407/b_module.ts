//! 모듈과 네임스페이스

export {add, subtract, num};

//? 1. 모듈
// : 코드를 하나의 단위로 묶어 관리하는 방법 
// : 독립 가능한 기능의 단위

// - 재사용성
// : 공통 코드를 모듈로 분리하여 여러 곳에서 재사용이 가능 

// - 유지보수 
// : 기능별로 코드를 분리하여 유지 보수의 효율성을 증가

// - 전역 스코프 오염 방지 
// : 이름 공간이 파일 단위로 제한되어 전역 이름 공간을 침범하지 X 
// : 모듈 내에서 선언된 변수, 함수, 클래스 등을 명시적으로 내보내지 않는 이상 
//   모듈 외부에서 접근할 수 X 

//! 모듈의 수출과 수입

//? 1. 모듈 내보내기(Export)

// : 모듈에서 함수, 클래스, 변수, 인터페이스 등(기능 등)을 외부로 내보낼 때 사용
// : export로 내보낸 기능은 다른 모듈에서 불러오기 (import)하여 사용 가능 
// >> 각 파일에 export {};을 사용하는경우 해당 파일이 모듈화 

// export 사용 
// 1. 기능의 내용 앞에 첨부
export let arr = [1, 2, 3];

// 2. 묶어서 첨부 
function add(x: number, y: number): number {
	return x + y;
}

function subtract(x: number, y: number):number {
	return x - y;
}


let num = 1;

//? 2. 모듈 불러오기(Import)
// : 다른 모듈에서 내보낸(export 된)요소를 가져올 때 사용 

// 기본 형태
// import {	모듈명 } from '파일경로';

// - 파일 경로
// : 불러오는 파일을 기준으로 경로를 작성 

//? 3. Default 모듈 내보내기 
// : 하나의 모듈(파일)에서 '단 하나의 기능이나 객체'를 기본적으로 내보내고 싶을 때
// 기본 형태
// : export default 키워드를 사용 (키워드 외에는 export와 동일하게 사용)
export default class Calculator {
	add(x: number, y: number): number {
		return x + y;
	}
}

//? 4. Default 모듈 불러오기
// : 일반 import문을 사용하여 불러오기 가능

// + 일반 import문과의 차이점
// : import 키워드 뒤에 중괄호 {} 없이 이름을 변경하여 불러오기가 가능
// (동일한 이름도 사용 가능)