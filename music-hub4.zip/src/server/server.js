


const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 5000;
const filePath = path.join(__dirname, 'members.json');

// Middleware
app.use(bodyParser.json());

// 회원가입 POST 요청 처리
app.post('/api/signup', (req, res) => {
    const { email, password, phone, nickname, birthdate } = req.body;

    // 기존 회원 데이터 불러오기
    let members = [];
    if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath);
        members = JSON.parse(data);
    }

    // 새로운 회원 객체 생성
    const newMember = { email, password, phone, nickname, birthdate };

    // 회원 데이터에 추가
    members.push(newMember);

    // 업데이트된 회원 데이터를 파일에 저장
    fs.writeFileSync(filePath, JSON.stringify(members, null, 2));

    res.status(201).json({ message: '회원가입이 완료되었습니다.' });
});

// 장르 선택 POST 요청 처리
app.post('/api/genres', (req, res) => {
    const { email, genre } = req.body;

    // 기존 회원 데이터 불러오기
    let members = [];
    if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath);
        members = JSON.parse(data);
    }

    // 회원 데이터에서 해당 이메일을 찾아 장르 정보 업데이트
    const updatedMembers = members.map((member) => {
        if (member.email === email) {
            return {
                ...member,
                genre: genre,
            };
        }
        return member;
    });

    // 업데이트된 회원 데이터를 파일에 저장
    fs.writeFileSync(filePath, JSON.stringify(updatedMembers, null, 2));

    res.status(200).json({ message: '장르 선택이 완료되었습니다.' });
});

// server.js

// 로그인 POST 요청 처리
app.post('/api/login', (req, res) => {
	const { email, password } = req.body;

	// 기존 회원 데이터 불러오기
	let members = [];
	if (fs.existsSync(filePath)) {
			const data = fs.readFileSync(filePath);
			members = JSON.parse(data);
	}

	// 입력한 이메일과 비밀번호가 일치하는 회원 찾기
	const user = members.find((member) => member.email === email && member.password === password);

	if (user) {
			res.status(200).json({ success: true });
	} else {
			res.status(401).json({ success: false });
	}
});


// 서버 시작
app.listen(port, () => {
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
});

