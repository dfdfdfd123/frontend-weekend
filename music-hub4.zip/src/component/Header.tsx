

import React, { useState } from 'react';
import LoginModal from './LoginModal';
import SignupModal from './SignupModal';
import FindIdModal from './FindIdModal';
import FindPwModal from './FindPwModal';
import GenreModal from './GenreModal';

const Header: React.FC = () => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [isSignupModalOpen, setSignupModalOpen] = useState(false);
    const [isFindIdModalOpen, setFindIdModalOpen] = useState(false);
    const [isFindPwModalOpen, setFindPwModalOpen] = useState(false);
    const [isGenreModalOpen, setGenreModalOpen] = useState(false);
    const [userEmail, setUserEmail] = useState('');

    const openModal = () => {
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
    };

    const openSignupModal = () => {
        setSignupModalOpen(true);
    };

    const closeSignupModal = () => {
        setSignupModalOpen(false);
    };

    const openFindIdModal = () => {
        setFindIdModalOpen(true);
    };

    const closeFindIdModal = () => {
        setFindIdModalOpen(false);
    };

    const openFindPwModal = () => {
        setFindPwModalOpen(true);
    };

    const closeFindPwModal = () => {
        setFindPwModalOpen(false);
    };

    const openGenreModal = () => {
        setGenreModalOpen(true);
    };

    const closeGenreModal = () => {
        setGenreModalOpen(false);
    };

		const handleSignupComplete = (email: string) => {
			closeModal(); // 회원가입 모달 닫기
			setUserEmail(email); // 이메일 저장
			openGenreModal(); // 장르 선택 모달 열기
	};
	

    return (
        <div className="home">
            <header className="header">
                <h1>Music-Hub</h1>
                {!userEmail ? (
                    <div className="auth-buttons">
                        <button onClick={openModal}>로그인</button>
                        <button onClick={openSignupModal}>회원가입</button>
                    </div>
                ) : (
                    <div className="user-info">
                        <p>{userEmail}, 안녕하세요.</p>
												<button>로그아웃</button>
                    </div>
                )}
            </header>

            {isModalOpen && (
                <LoginModal
                    onClose={closeModal}
                    onSignup={handleSignupComplete}
                    onFindId={openFindIdModal}
                    onFindPw={openFindPwModal}
                />
            )}
            {isSignupModalOpen && <SignupModal onClose={closeSignupModal} onSignupComplete={handleSignupComplete} />}
            {isFindIdModalOpen && <FindIdModal onClose={closeFindIdModal} />}
            {isFindPwModalOpen && <FindPwModal onClose={closeFindPwModal} />}
            <GenreModal isOpen={isGenreModalOpen} onClose={closeGenreModal} userEmail={userEmail} />
        </div>
    );
};

export default Header;


