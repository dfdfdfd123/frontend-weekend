import React, { useState } from 'react';
import '../styles/LoginModal.css';

interface LoginModalProps {
    onClose: () => void;
    onSignup: (email: string) => void; // 타입 수정
    onFindId: () => void;
    onFindPw: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onSignup, onFindId, onFindPw }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    // LoginModal.tsx

// LoginModal.tsx

const handleSubmit = (e: React.FormEvent) => {
	e.preventDefault();

	if (!email || !password) {
			alert('아이디와 비밀번호를 입력하세요.');
			return;
	}

	fetch('/api/login', {
			method: 'POST',
			headers: {
					'Content-Type': 'application/json',
			},
			body: JSON.stringify({ email, password }),
	})
	.then((response) => response.json())
	.then((data) => {
			if (data.success) {
					alert('로그인 성공!');
					onClose(); // 모달 닫기
			} else {
					alert('아이디 또는 비밀번호가 일치하지 않습니다.');
			}
	})
	.catch((error) => {
			console.error('Error during login:', error);
			alert('로그인 중 오류가 발생했습니다.');
	});
};


    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-button" onClick={onClose}>X</button>
                <div className="login-form">
                    <h2>로그인</h2>
                    <form onSubmit={handleSubmit}>
                        <label>
                            <input
                                type="text"
                                name="id"
                                placeholder="아이디 (이메일)"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </label>
                        <label>
                            <input
                                type="password"
                                name="password"
                                placeholder="비밀번호"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </label>
                        <label>
                            <input type="checkbox" name="remember" />
                            <span>로그인 유지</span>
                        </label>
                        <div className="login-help">
                            <button type="button" onClick={onFindId}>아이디 찾기</button>
                            <button type="button" onClick={onFindPw}>비밀번호 찾기</button>
                            <button type="button" onClick={() => onSignup(email)}>회원가입</button>
                        </div>
                        <button type="submit">로그인</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default LoginModal;


