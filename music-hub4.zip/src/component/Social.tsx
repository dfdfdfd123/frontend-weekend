import React from 'react'

export default function Social() {
	return (
		<div>
			<h2>안녕하세요</h2>
		</div>
	)
}
