import React from 'react';


const MainContent: React.FC = () => {
  return (
    <main className="main-content">
      <section className="recommendations">
        <h2>오늘의 추천곡</h2>
        <div className="items">
          {/* 추천곡 리스트 */}
        </div>
      </section>
      <section className="popular-music">
        <h2>인기음악</h2>
        <div className="items">
          {/* 인기 음악 리스트 */}
        </div>
      </section>
      <section className="popular-artists">
        <h2>인기 아티스트</h2>
        <div className="items">
          {/* 인기 아티스트 리스트 */}
        </div>
      </section>
			<div className="news-and-top">
      <section className="news">
				<h2>음악 뉴스</h2>
       
      </section>
      <section className="top-list">
        <h2>Top</h2>
        <ol>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ol>
      </section>
			</div>
    </main>
  );
};

export default MainContent;


