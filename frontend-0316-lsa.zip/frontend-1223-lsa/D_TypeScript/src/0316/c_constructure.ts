// c_constructure.ts

//! 1. 타입스크립트 프로젝트 디렉토리 구조

//? src(source)
// : 소스 코드를 저장
// : 모든 타입스크립트 파일(.ts)을 해당 폴더 내에 작성

//? node_modules
// : 프로젝트에서 사용하는 모든 NPM 패키지를 저장

//? package.json
// : 프로젝트의 메타데이터와 사용하는 npm 패키지의 목록을 저장


//? tsconfig.json
// : 타입스크립트 컴파일러의 설정을 저장