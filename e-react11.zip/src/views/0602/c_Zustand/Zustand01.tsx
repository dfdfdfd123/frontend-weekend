import React from 'react'

export default function Zustand01() {
	return (
		<div>
			
		</div>
	)
}
