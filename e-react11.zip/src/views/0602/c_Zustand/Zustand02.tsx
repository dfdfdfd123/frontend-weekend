import { readConfigFile } from "typescript";

readConfigFile