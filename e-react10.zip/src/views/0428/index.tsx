

import GoalApp from "./a_array/GoalApp"
import Effects01 from "./b_Effect/Effects01"
import Effects02 from "./b_Effect/Effects02"
import Effects03 from "./b_Effect/Effects03"
import Practice01 from "./c_Practice/Practice01"
import Practice02 from "./c_Practice/Practice02"




// 타이머 기능을 부수 효과로 사용 
export default function index() {


	return (
		<div>

	<h1 style={{backgroundColor: 'pink'

	}}>0428</h1>

		<h2>1. 배열 렌더링 (State&Ref)</h2>
		<GoalApp />
	  	

		{/*
	b_Effects
	>> Effects01.tsx 
*/}
			<h2>2. 리엑트 부수 효과  </h2>
			<Effects01/>
			<Effects02/>
			<Effects03/>

			<h2>3. 리엑트 부수 효과 예제</h2>
			<Practice01 />
			<Practice02 />
		</div>

		
	)
}
