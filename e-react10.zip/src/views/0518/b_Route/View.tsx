import React from 'react'

export default function View() {
	return (
		<div>
			
		</div>
	)
}
