import StateProps01 from "./a_State_Props/StateProps01"
import StateProps02 from "./a_State_Props/StateProps02"
import USeRef from "./b_useRef/UseRef"
import UseRef02 from "./b_useRef/UseRef02"
import Arr01 from "./c_Array/Arr01";
import Arr02 from "./c_Array/Arr02";

const images = [
	'https://cdn.pixabay.com/photo/2017/09/25/13/12/puppy-2785074_1280.jpg',
	'https://cdn.pixabay.com/photo/2023/09/19/12/34/dog-8262506_640.jpg',
	'https://cdn.pixabay.com/photo/2018/05/11/08/11/dog-3389729_640.jpg',
	'https://cdn.pixabay.com/photo/2020/06/30/22/34/dog-5357794_640.jpg',
	'https://cdn.pixabay.com/photo/2017/07/31/21/15/dog-2561134_640.jpg'

];


export default function index() {
	return (
		<div>

	<h1 style={{backgroundColor: 'pink'

	}}>0427</h1>

		<h2>1. 컴포넌트 트리 안의 상태</h2>
	  		<StateProps01 />
				<StateProps02/>

			<h2>2. 변경 가능한 참조 객체 생성  </h2>
			<USeRef/>
			<UseRef02 images={images}/>

			<h2>3. 배열 렌더링</h2>
			<Arr01/>
			<Arr02/>
		</div>

		
	)
}
