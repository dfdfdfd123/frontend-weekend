import React, { useState } from 'react'
import  useCounter  from './hooks/useCounter'

//! 메인 컴포넌트 
// : 실제 화면에 출력될 로직 
// , - custom Hook을 사용하는 컴포넌트
// - Custom Hook은 일반 React Hook 사용법과 동일




//? 초기값을 매개변수로 전달받고, 카운터를 증가/감소시키고 초기화하는 함수들을 반환 
export default function Custom01() {
	//! 객체의 구조 분해 할당 
	const { count, increment, decrement, reset } = useCounter();

	return (
    <div>
			<h3>{count}</h3>
			<button onClick={increment}>증가</button>
			<button onClick={decrement}>감소</button>
			<button onClick={reset}>초기화</button>
		</div> 
  )

  
}
