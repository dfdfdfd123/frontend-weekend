// b_javaScript.js

let message = 'hello';

console.log(message.toUpperCase()); //HELLO

message(); // - Error

// message(); - Error (TypeError: message is not a function.)
// : JS는 코드 실행 시 에러를 확인