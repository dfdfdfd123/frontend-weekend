console.log('Hello TypeScript');
// 위의 ts 파일 명령어를 실행하기 위해서는
// 해당 파일을 js 파일로 '컴파일'
// tsc 파일명.ts
// 컴파일 된 js파일을 Node.js 런타임 환경에서 실행
// : node 파일명.js
