import React from 'react'

//! 온라인 투표 시스템

//? 문제 요구 사항
// - 후보자 목록은 객체의 배열로 관리
// - 각 객체는 name과 votes 두 가지 키를 가짐
// - 사용자는 후보자 목록 중 하나를 선택하고 투표
// - 투표 버튼을 누르면 선택된 후보자의 투표 수가 증가

export default function Practice02() {
  return (
    <div>Practice02</div>
  )
}