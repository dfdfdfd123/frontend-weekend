import React from 'react'

export default function Practice02() {
  return (
    <div>Practice02</div>
  )
}
