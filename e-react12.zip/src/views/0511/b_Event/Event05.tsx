import React from 'react'

export default function Event05() {
  return (
    <div>Event05</div>
  )
}
