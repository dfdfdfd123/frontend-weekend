import React, { useState } from 'react';
import LoginModal from './LoginModal';
import SignupModal from './SignupModal';


const Header: React.FC = () => {

  const [isModalOpen, setModalOpen] = useState(false);
  const [isSignupModalOpen, setSignupModalOpen] = useState(false);

  const openModal = () => {
    setModalOpen(true);
};

const closeModal = () => {
    setModalOpen(false);
};

const openSignupModal = () => {
  setSignupModalOpen(true);
};

const closeSignupModal = () => {
  setSignupModalOpen(false);
};

  return (


     <div className="home">
     <header className="header">
         <h1>Music-Hub</h1>
         <div className="auth-buttons">
             <button onClick={openModal}>로그인</button>
             <button onClick={openSignupModal}>회원가입</button>
         </div>
     </header>
     {/* Other parts of the Home component */}
     {isModalOpen && <LoginModal onClose={closeModal} />}
     {isSignupModalOpen && <SignupModal onClose={closeSignupModal} />}
 </div>
    
  );
};



export default Header;

