import React from 'react';
import './LoginModal.css';

interface LoginModalProps {
    onClose: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose }) => {
    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-button" onClick={onClose}>X</button>
                <div className="login-form">
                    <h2>로그인</h2>
                    <form>
                        <label>
                            <span>아이디: (이메일 / 전화번호 / 닉네임)</span>
                            <input type="text" name="id" />
                        </label>
                        <label>
                            <span>비밀번호:</span>
                            <input type="password" name="password" />
                        </label>
                        <label>
                            <input type="checkbox" name="remember" />
                            <span>로그인 유지</span>
                        </label>
                        <div className="login-help">
                            <button type="button">아이디 찾기</button>
                            <button type="button">비밀번호 찾기</button>
                            <button type="button">회원가입</button>
                        </div>
                      
                        <button type="submit">가입</button>
                    </form>
                   
                </div>
            </div>
        </div>
    );
};

export default LoginModal;
