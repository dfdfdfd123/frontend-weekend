import React from 'react';
import './SignupModal.css';

interface SignupModalProps {
    onClose: () => void;
}

const SignupModal: React.FC<SignupModalProps> = ({ onClose }) => {
    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-button" onClick={onClose}>X</button>
                <div className="signup-form">
                    <h2>회원가입</h2>
                    <form>
                        <label>
                            <span>필수 아이디(이메일):</span>
                            <input type="text" name="email" />
                        </label>
                        <label>
                            <span>비밀번호:</span>
                            <input type="password" name="password" />
                        </label>
                        <label>
                            <span>비밀번호 확인:</span>
                            <input type="password" name="confirmPassword" />
                        </label>
                        <label>
                            <span>전화번호:</span>
                            <input type="tel" name="phone" />
                        </label>
                        <label>
                            <span>선택 닉네임:</span>
                            <input type="text" name="nickname" />
                        </label>
                        <label>
                            <span>생년월일(6자리):</span>
                            <input type="text" name="birthdate" />
                        </label>
                        <button type="submit">가입</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default SignupModal;

