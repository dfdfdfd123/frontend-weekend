import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './component/Header';
import Sidebar from './component/Sidebar';
import MainContent from './component/MainContent';


import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Header />
        <div className="app-body">
          <Sidebar />
          <MainContent />
            <Routes>
            
            </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;

