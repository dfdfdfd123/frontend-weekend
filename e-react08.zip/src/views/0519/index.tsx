import React from "react";




export default function Index() {
  return (
    <div>
     
      <h1
        style={{
          backgroundColor: "pink",
        }}
      >
        0519
      </h1>

      <h2>1. Practice</h2>
     

      <h2>2. Global State</h2>
      
      
    </div>
  );
}